#if ($PACKAGE_NAME && $PACKAGE_NAME != "")package $PACKAGE_NAME;#end

#set($DomainRepository = $Domain.split("Entity")[0] + "Repository" )
#set($domainRepositoryObject = $DomainRepository.substring(0,1).toLowerCase() + $DomainRepository.substring(1))
#set($domainObject = $Domain.substring(0,1).toLowerCase() + $Domain.substring(1))
#set($DomainService = $Domain.split("Entity")[0] + "Service")
#set($NAME = $Domain.split("Entity")[0] + "ServiceImpl")
#set($LowerName = $Domain.toLowerCase())
#set($DominPackage = $Domain.toLowerCase().split("Entity")[0]  )



import com.irisaco.mss.hamsoo.bpm.model.entity.$DominPackage.$Domain;
import com.irisaco.mss.hamsoo.bpm.repository.jpa.$DominPackage.$DomainRepository;
import com.irisaco.mss.hamsoo.bpm.service.api.$DominPackage.$DomainService;
import org.springframework.stereotype.Service;
import com.irisaco.mss.hamsoo.bpm.common.exception.BusinessException;

@Service
public class $NAME implements $DomainService {
		  private $DomainRepository $domainRepositoryObject;

  public $NAME($DomainRepository $domainRepositoryObject) {
        this.$domainRepositoryObject=$domainRepositoryObject;
    }

   
    @Override
    public $DomainRepository getRepository() {
        return  $domainRepositoryObject;
    }


    @Override
    public $Domain findByIdOrElseThrow($IdType id) {
        if (id == null) {
            throw new BusinessException("error.${LowerName}.idIsNotValid");
        }
        return findById(id).orElseThrow(() -> new BusinessException("error.${LowerName}.idIsNotValid"));
    }

    @Override
    public void delete$Domain($IdType id) {
        $Domain $domainObject = findByIdOrElseThrow(id);
        delete($domainObject);
    }
   
}