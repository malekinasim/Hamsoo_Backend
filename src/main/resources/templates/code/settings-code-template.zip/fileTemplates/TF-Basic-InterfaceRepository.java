#if ($PACKAGE_NAME && $PACKAGE_NAME != "")package $PACKAGE_NAME;#end
#set($DomainRepository = $Domain.split("Entity")[0] + "Repository" )
#set($DominPackage = $Domain.toLowerCase().split("Entity")[0]  )
#set($DomainIdFirstUpper = $DomainId.substring(0,1).toUpperCase() + $DomainId.substring(1).split("Entity")[0])


import com.irisaco.mss.hamsoo.bpm.model.entity.$DominPackage.$Domain;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public interface $DomainRepository  extends HamsooRepository<$Domain, $IdType> {

Page<$Domain> findAll(Specification specification, Pageable pageable);

}