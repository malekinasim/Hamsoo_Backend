#if ($PACKAGE_NAME && $PACKAGE_NAME != "")package $PACKAGE_NAME;#end
#set($DomainService = $Domain.split("Entity")[0] + "Service")
#set($DominPackage = $Domain.toLowerCase().split("Entity")[0]  )
#set($DomainRepository = $Domain.split("Entity")[0] + "Repository" )

import com.irisaco.mss.hamsoo.bpm.model.entity.$DominPackage.$Domain;
import com.irisaco.mss.hamsoo.bpm.repository.jpa.$DominPackage.$DomainRepository;
import com.irisaco.mss.hamsoo.bpm.service.api.base.BaseService;

public interface $DomainService extends BaseService<$Domain, $IdType,$DomainRepository > {
	 $Domain findByIdOrElseThrow($IdType id);

    void delete$Domain($IdType id);

}