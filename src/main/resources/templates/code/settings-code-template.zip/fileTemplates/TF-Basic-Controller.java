#if ($PACKAGE_NAME && $PACKAGE_NAME != "")package $PACKAGE_NAME;#end
#set($domainObject = $Domain.substring(0,1).toLowerCase() + $Domain.substring(1))
#set($domainObjectFirstUpper = $Domain.substring(0,1).toUpperCase() + $Domain.substring(1))
#set($NAME = "${domainObjectFirstUpper}Controller")
#set($DomainService = "${Domain}Service")
#set($domainServiceObject = $DomainService.substring(0,1).toLowerCase() + $DomainService.substring(1))
#if ($RESTUriOfDomain.endsWith("s"))
    #set($RESTUriOfDomains = $RESTUriOfDomain + "es")
#else
    #set($RESTUriOfDomains = $RESTUriOfDomain + "s")
#end
#set($DominPackage = $Domain.toLowerCase().split("Entity")[0]  )

import com.irisaco.mss.hamsoo.bpm.service.api.$DominPackage.$DomainService;
import com.irisaco.mss.hamsoo.bpm.model.entity.$DominPackage.$Domain;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Api(value = "$Domain", description = "Rest full controller of $Domain!")
@RequestMapping("/api")
public class $NAME {

    
    private $DomainService $domainServiceObject;
	 public $NAME($DomainService $domainServiceObject) {
        this.$domainServiceObject = $domainServiceObject;
    }

	
	 //----------get by id---------
    @ApiOperation(value = "find a $Domain by id", response = ${Domain}.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 417, message = "Expectation Failed")})
    @GetMapping("/${RESTUriOfDomain}/{id}")
    public ResponseEntity<?> get${domainObjectFirstUpper}ById(@PathVariable("id") $IdType id){
		
		
		 $Domain $domainObject = ${domainServiceObject}.findByIdOrElseThrow(id);
        return new ResponseEntity<>( $domainObject, HttpStatus.OK);
    }

  
	 //----------get All---------
    @ApiOperation(value = "list of all $Domain", response = ${Domain}.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 204, message = "NO_CONTENT"),
            @ApiResponse(code = 417, message = "Expectation Failed")})
    @GetMapping(value = "/${RESTUriOfDomain}/list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<?>> listAll${domainObjectFirstUpper}(  @RequestParam int page, @RequestParam int size)  {
        Page<$Domain> ${domainObject}Page= ${domainServiceObject}.findAll(PageRequest.of(page, size));
        if (${domainObject}Page.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(${domainObject}Page, HttpStatus.OK);
        }
    }

  
	//----------Save---------
    @ApiOperation(value = "save a $Domain", response = HttpStatus.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "created"),
            @ApiResponse(code = 417, message = "Expectation Failed")})
    @PostMapping(value = "/${RESTUriOfDomain}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> save${domainObjectFirstUpper}(@RequestBody $Domain $domainObject) {
        $Domain returnValue =  ${domainServiceObject}.save($domainObject);
        if (returnValue.getId() !=null ) {
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>( HttpStatus.EXPECTATION_FAILED);
        }
    }
	
     //----------delete by id---------
    @ApiOperation(value = "delete a $Domain by id", response = HttpStatus.class)
    @ApiResponses(value = {
            @ApiResponse(code = 204, message = "No Content"),
            @ApiResponse(code = 417, message = "Expectation Failed")})
    @DeleteMapping("/${RESTUriOfDomain}/{id}")
    public ResponseEntity<$Domain> delete${domainObjectFirstUpper}(@PathVariable("id") $IdType id){
         ${domainServiceObject}.delete${domainObjectFirstUpper}(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}